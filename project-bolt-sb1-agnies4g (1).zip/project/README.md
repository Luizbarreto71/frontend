# 🧠 MindKids - Plataforma Educativa Premium

## 🌟 Versão 2.0 - Agora com IA Luna!

Uma plataforma educativa inovadora que utiliza jogos interativos especializados para auxiliar pais e educadores na observação de padrões de desenvolvimento infantil e possíveis sinais relacionados ao Transtorno do Espectro Autista (TEA).

## ✨ Novas Funcionalidades v2.0

### 🤖 Luna - Assistente IA Especializada
- **Personagem amigável**: Robô Luna com apresentação animada
- **Chat inteligente**: Respostas sobre autismo e desenvolvimento infantil
- **Base de conhecimento**: Informações especializadas e orientações
- **Interface infantil**: Design pensado para crianças e famílias

### 🌙 Modo Escuro
- **Toggle de tema**: Alternância entre modo claro e escuro
- **Persistência**: Salva preferência do usuário
- **Transições suaves**: Mudanças animadas entre temas
- **Acessibilidade**: Melhor experiência visual

### 🎮 3 Novos Jogos Especializados
1. **🔷 Jogo das Formas** - Reconhecimento de formas geométricas
2. **🔢 Jogo dos Números** - Reconhecimento numérico (1-10)
3. **🔊 Jogo dos Sons** - Associação som-animal

### 📱 Design Responsivo Aprimorado
- **Mobile-first**: Otimizado para dispositivos móveis
- **Breakpoints inteligentes**: Adaptação perfeita para todos os tamanhos
- **Navegação móvel**: Menu adaptado para telas pequenas

## 🎯 Jogos Disponíveis (Total: 6)

### Jogos Originais:
1. **🧠 Jogo da Memória** - Memória visual e concentração
2. **⚡ Jogo de Sequências** - Memória sequencial e padrões
3. **🎨 Jogo das Cores** - Reconhecimento visual

### Novos Jogos:
4. **🔷 Jogo das Formas** - Coordenação visual-motora
5. **🔢 Jogo dos Números** - Habilidades matemáticas básicas
6. **🔊 Jogo dos Sons** - Processamento auditivo

## 🚀 Tecnologias Utilizadas

- **React 18** - Framework principal
- **TypeScript** - Tipagem estática
- **Tailwind CSS** - Estilização com modo escuro
- **Lucide React** - Ícones modernos
- **Vite** - Build tool rápido
- **React Router** - Navegação SPA

## 📋 Funcionalidades Principais

### 🔐 Sistema Premium
- **Pagamento único**: R$ 19,90 - Acesso vitalício
- **Múltiplos perfis**: Acompanhe várias crianças
- **Relatórios detalhados**: Análises completas de desempenho
- **Backup automático**: Dados salvos localmente

### 📊 Relatórios Inteligentes
- **Análise de padrões**: Identificação de tendências
- **Relatórios imprimíveis**: Documentos para profissionais
- **Acompanhamento temporal**: Evolução do desenvolvimento
- **Observações educativas**: Insights sobre habilidades

### 🛡️ Segurança e Privacidade
- **Dados locais**: Informações armazenadas no dispositivo
- **Sem coleta**: Nenhum dado enviado para servidores
- **Disclaimer claro**: Aviso sobre não ser diagnóstico médico

## 🔧 Instalação e Uso

### Pré-requisitos
- Node.js 16+
- npm ou yarn

### Instalação
```bash
# Clone o repositório
git clone https://github.com/seu-usuario/mindkids.git

# Entre no diretório
cd mindkids

# Instale as dependências
npm install

# Execute em modo desenvolvimento
npm run dev

# Build para produção
npm run build
```

### Integração com Backend Existente
Se você já tem um projeto Node.js:

1. **Copie os arquivos frontend** para sua estrutura existente
2. **Mantenha seu backend intacto**
3. **Configure as rotas** para servir o frontend
4. **Adapte as APIs** conforme necessário

## 🤖 Configuração da IA Luna

### Respostas Offline
A Luna funciona com respostas pré-programadas sobre:
- Sinais de autismo
- Desenvolvimento infantil
- Como usar os jogos
- Interpretação de relatórios
- Onde buscar ajuda profissional

### Integração com IA Real (Opcional)
Para conectar com OpenAI, Gemini ou similar:

```javascript
// Exemplo de integração
const response = await fetch('/api/ai/chat', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ message: userMessage })
});
```

## 🎨 Personalização do Tema

### Cores do Autismo
O design utiliza as cores oficiais do autismo:
- **Azul**: Cor principal do autismo
- **Vermelho**: Quebra-cabeças (símbolo do autismo)
- **Verde**: Esperança e crescimento
- **Amarelo**: Alegria e otimismo
- **Roxo**: Criatividade e imaginação

### Modo Escuro
Configurado automaticamente com:
- Detecção de preferência do sistema
- Persistência da escolha do usuário
- Transições suaves entre temas

## ⚠️ Importante - Disclaimer

**O MindKids é uma ferramenta educativa e NÃO fornece diagnósticos médicos.**

- Os jogos são para observação educativa
- Relatórios não substituem avaliação profissional
- Sempre consulte pediatras ou especialistas
- Use como complemento, não como diagnóstico

## 📞 Suporte e Contribuição

### Reportar Problemas
- Abra uma issue no GitHub
- Descreva o problema detalhadamente
- Inclua screenshots se necessário

### Contribuir
1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## 🙏 Agradecimentos

- Famílias que inspiraram este projeto
- Profissionais de saúde que orientaram o desenvolvimento
- Comunidade de desenvolvedores que contribuíram

---

**✨ MindKids v2.0 - Agora com Luna, sua assistente IA especializada! ✨**

*Desenvolvido com 💜 para ajudar famílias e crianças*